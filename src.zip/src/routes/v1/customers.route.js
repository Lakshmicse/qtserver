// const express = require('express');
// const customizationController = require('../../Controllers/customer.controller')

// const uploadMultiple = require('../../middlewares/upload-customization-images');
// require('../../middlewares/auth');
// require('../../middlewares/validate');

// const auth = require('../../middlewares/auth');
// const validate = require('../../middlewares/validate');
// const userValidation = require('../../validations/user.validation');

// const router = express.Router();
// router.route('/').get(auth('getUsers'),customizationController.getcusDriverList).post(uploadMultiple,auth('getUsers'),customizationController.createcusDriver);
// router
//   .route('/:CustomerDriverId')
//   .get(auth('getUsers'),customizationController.getcusDriver)
//   .patch(auth('getUsers'),customizationController.updatecusDriver)
//   .delete(auth('getUsers'),customizationController.deletecusDriver);
//   module.exports = router;
